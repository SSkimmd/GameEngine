#pragma once
#include "player.hpp"
#include "move.hpp"
#include "rotate.hpp"

class Game {
public:
	Game();
	~Game();
	void Start();
};